/**
 * 
 */
function validateRoomType() {
	var roomType = document.forms.getElementById("roomType");

	/*var result = roomType.options[e.selectedIndex].value;*/

	if (roomType == "Select") {
		alert("Choose One Option");
		return false;
	} else
		return true;
}