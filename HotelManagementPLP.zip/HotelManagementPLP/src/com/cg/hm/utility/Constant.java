package com.cg.hm.utility;

/**
 * Constant Values
 * 
 * @author rohitaku
 *
 */
public interface Constant {
	String ADMINID = "System";
	String ADMINPASS = "Capgemini123";
	String message = "message";
	String message2 = "message2";
	String INVALID = "Invalid Id or Password!!!";
	String HOTELADDED = "Hotel Added Successfully!!!";
	String ROOMADDED = "Room Added Successfully!!!";
	String NOROOM = "No Room Available in This Hotel";
	String ROOMDELETED = "Room Deleted Successfully!!!";
	String HOTELDELETED = "Hotel Deleted Successfully!!!";
	String HOTELMODIFIED = "Hotel Modified Successfully!!!";
	String ROOMMODIFIED = "Room Modified Successfully!!!";
	String NOROOMBOOKED = "No Room Booked in This Hotel";
	String[] DROPDOWNLIST = { "Select", "Standard non A/C room",
			"Standard A/C room", "Executive A/C room", "Deluxe A/C room" };
	String HOMEPAGE="Home";
	String ADMINPAGE="Admin";
	String LOGINPAGE="Login";
	String ADDHOTELPAGE="addHotel";
	String ADDROOMPAGE="addRoom";
	String HOTELLISTPAGE="HotelList";
	String DELETEROOMPAGE="deleteRoom";
	String DELETEHOTELPAGE="deleteHotel";
	String MODIFYROOMPAGE="modifyRoom";
	String MODIFYHOTELPAGE="modifyHotel";
	String BOOKINGDETAILSBYDATEPAGE="BookingDetailsByDate";
	String HOTELBOOKINGDETAILSPAGE="HotelBookingDetails";
	String HOTELGUESTLISTPAGE="HotelGuestList";
	
}
